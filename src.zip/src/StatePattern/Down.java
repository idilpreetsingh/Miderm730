package StatePattern;

public class Down extends ServiceState {
    public Down() {
        super();
    }

    @Override
    void possibleOp()
    {
        System.out.println("Cuurent state is Down .Please choose to move next:");
        
        System.out.println(HEALTH_CHECK_GOOD+ " HEALTH_CHECK_GOOD");
        
        
    }

    @Override
    void goToNextState(ServiceContext context,int opCode) {
        if (opCode==0) {
            context.setState(new Ready());
        }
        else
        {
            System.out.println("Wrong input");
        }
    }
}
