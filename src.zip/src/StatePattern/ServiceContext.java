package StatePattern;


public class ServiceContext {
    private String name;
    private ServiceState state;
   

    @Override
    public String toString() {
        return "ServiceContext: " + name + ", state=" + state.getClass();
    }

    public ServiceContext(String name) {
        

    }

    public ServiceContext(ServiceState state, String name) {
        this.state = state;
        this.name = name;
        
    }

    public ServiceState getState() {
        return state;
    }

    public void setState(ServiceState state) {
        this.state = state;
    }

    public void displayState()
    {
        
    }
    public void goPossibleOp() {
        state.possibleOp();
    }
    public void goToNextState(int opCode) {
        state.goToNextState(this, opCode);
    }
    
}
