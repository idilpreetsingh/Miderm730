package StatePattern;


public class Unknown extends ServiceState {

    public Unknown() {
        super();
    }
    @Override
    void possibleOp()
    {
        System.out.println("Cuurent state is Unknown .Please choose to move next:");
        System.out.println(HEALTH_CHECK_GOOD+" HEALTH_CHECK_GOOD");
        System.out.println(HEALTH_CHECK_BAD+ " HEALTH_CHECK_BAD");
        
    }
    @Override
    void goToNextState(ServiceContext context,int opCode) {
        if (opCode==HEALTH_CHECK_GOOD) {
            context.setState(new Ready());
        } else if (opCode==SERVICE_TIME_OUT || opCode==HEALTH_CHECK_BAD){
            context.setState(new Down());
        }
        else
        {
            System.out.println("Wrong input");
        }
    }
}
