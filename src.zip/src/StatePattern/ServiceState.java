package StatePattern;

public abstract class ServiceState {
    public static final int SERVICE_TIME_OUT = 1;
    public static final int HEALTH_CHECK_BAD = 2;
    public static final int HEALTH_CHECK_GOOD = 3;
    public static final int HEALTH_SERVICE_DISABLE = 4;
    public static final int HEALTH_SERVICE_ENABLE = 5;
    

    public ServiceState() {
        
    }

    
    abstract void possibleOp();
    abstract void goToNextState(ServiceContext context,int opCode);
}
