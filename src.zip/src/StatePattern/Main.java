package StatePattern;


import java.util.Scanner;

public class Main {

    private static Scanner in = new Scanner(System.in);
    //private static UpdateServicesThread updateServicesThread = new UpdateServicesThread();
    static ServiceContext serviceContext;

    public static void main(String[] args) {
        init();
        menu();
    }

    private static void init() {
        serviceContext = new ServiceContext("Health Care Srvice 1");
        serviceContext.setState(new Unknown());
        
    }

    private static void menu() {
        int choice = 0;
        do {
            try {
                serviceContext.goPossibleOp();
                choice = Integer.parseInt(in.nextLine());
                serviceContext.goToNextState(choice);
            } catch (Exception ignored) {
            }
        } while (choice != 0);
    }

    
    
}
