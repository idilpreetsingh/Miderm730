package StatePattern;


public class Ready extends ServiceState {
    public Ready() {
        super();
    }

    

    @Override
    void possibleOp()
    {
        System.out.println("Cuurent state is Ready .Please choose to move next:");
        System.out.println(HEALTH_CHECK_BAD+ " HEALTH_CHECK_BAD");
        System.out.println(SERVICE_TIME_OUT+" SERVICE_TIME_OUT");
        System.out.println(HEALTH_SERVICE_DISABLE+" HEALTH_SERVICE_DISABLE");
        
    }
    @Override
    public void goToNextState(ServiceContext context,int opCode) {
        if (opCode==HEALTH_SERVICE_DISABLE) {
            context.setState(new Disabled());
        } else if (opCode==HEALTH_CHECK_BAD){
            context.setState(new Down());
        }
        else if (opCode==SERVICE_TIME_OUT){
            context.setState(new Unknown());
        }
        else
        {
            System.out.println("Wrong input");
        }
    }
}
