package StatePattern;


public class Disabled extends ServiceState {
    public Disabled() {
        super();
    }
    @Override
    void possibleOp()
    {
        System.out.println("Cuurent state is Disabled .Please choose to move next:");
        System.out.println(HEALTH_SERVICE_ENABLE+ " HEALTH_SERVICE_ENABLE");
        
        
    }
    @Override
    public void goToNextState(ServiceContext context,int opCode) {
        if(opCode==HEALTH_SERVICE_ENABLE)
        {
            context.setState(new Unknown());
        }
        else 
        {
            System.out.println("Wrong input...");
        }
    }
}
