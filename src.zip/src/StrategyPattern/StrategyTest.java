package StrategyPattern;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import StrategyPattern.AuthorSortStrategy;
import StrategyPattern.BookInformation;
import StrategyPattern.BookLibrarian;
import StrategyPattern.SortStrategy;
import StrategyPattern.TitleSortStrategy;
import StrategyPattern.YearSortStrategy;

/**
 *
 * @author 
 */
public class StrategyTest {
    BookLibrarian library;
    ArrayList<BookInformation> books;
    SortStrategy titleSortStrategy = new TitleSortStrategy();
    SortStrategy authorSortStrategy = new AuthorSortStrategy();
    SortStrategy yearSortStrategy = new YearSortStrategy();
    public StrategyTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @StrategyPattern.BeforeClass
    public void setUp() {
        books = new ArrayList<>();
        books.add(new BookInformation("Michael Wolf          ", "Fire and Fury: Inside the Trump White House    ", 2018	, "\t	summary book 1"));
        books.add(new BookInformation("A. J. Finn            ", "The Woman in the Window                        ", 2018	, "\t	summary book 2"));
        books.add(new BookInformation("Rupi Kaur             ", "Milk and Honey                                 ", 2015	, "\t	summary book 3"));
        books.add(new BookInformation("Madeleine L Engle     ", "A Wrinkle in Time (Time Quintet Series #1)     ", 2007	, "\t	summary book 4"));
        books.add(new BookInformation("Rupi Kaur             ", "The Sun and Her Flowers                        ", 2017	, "\t	summary book 5"));
        books.add(new BookInformation("Mark Manson           ", "The Subtle Art of Not Giving a F*ck            ", 2016	, "\t	summary book 6"));
        books.add(new BookInformation("Courtney Reum         ", "Shortcut Your Startup: Speed Up Success...     ", 2018	, "\t	summary book 7"));
        books.add(new BookInformation("Pete Souza            ", "Obama: An Intimate Portrait                    ", 2017	, "\t	summary book 8"));
        books.add(new BookInformation("Ben Lynch             ", "Dirty Genes: A Breakthrough Program to...      ", 2018	, "\t	summary book 9"));
        books.add(new BookInformation("Christine Comaford    ", "Power Your Tribe: Create Resilient Teams...    ", 2018	, "\t	summary book 10"));
        books.add(new BookInformation("Kristin Hannah        ", "The Great Alone                                ", 2018	, "\t	summary book 11"));
        books.add(new BookInformation("Celeste Ng            ", "Little Fires Everywhere                        ", 2017	, "\t	summary book 12"));
        books.add(new BookInformation("Wayne Jonas           ", "How Healing Works: Get Well and Stay ...       ", 2018	, "\t	summary book 13"));
        books.add(new BookInformation("Jordan B. Peterson    ", "12 Rules for Life: An Antidote to Chaos        ", 2018	, "\t	summary book 14"));
        books.add(new BookInformation("Karen M. McManus      ", "One of Us Is Lying                             ", 2017	, "\t	summary book 15"));
        books.add(new BookInformation("Lisa Wingate          ", "Before We Were Yours                           ", 2017	, "\t	summary book 16"));
        books.add(new BookInformation("Angie Thomas          ", "The Hate U Give                                ", 2017	, "\t	summary book 17"));
        books.add(new BookInformation("Martha Hall Kelly     ", "Lilac Girls                                    ", 2017	, "\t	summary book 18"));
        books.add(new BookInformation("Humble The Poet       ", "UnLearn: 101 Simple Truths For A Better Life   ", 2014	, "\t	summary book 19"));
        books.add(new BookInformation("Humble The Poet       ", "Beneath The Surface: 101 Honest Truths...      ", 2015	, "\t	summary book 20"));
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
     @Test
     public void testAuthorSort() {
         library = new StrategyPattern.BookLibrarian(authorSortStrategy, books);
         library.sortBooks();
         assertTrue(books.get(0).getAuthor().equals("Michael Wolf          "));
         assertTrue(books.get(20).getAuthor().equals("Humble The Poet       "));
     }
     @Test
     public void testTitleSort() {
         library = new StrategyPattern.BookLibrarian(titleSortStrategy, books);
         library.sortBooks();
         assertTrue(books.get(0).getTitle().equals("Title 1"));
         assertTrue(books.get(8).getTitle().equals("Title 9"));
     }
     @Test
     public void testYearSort() {
         library = new StrategyPattern.BookLibrarian(yearSortStrategy, books);
         library.sortBooks();
         assertTrue(books.get(0).getYearpublished()==2010);
         assertTrue(books.get(8).getYearpublished()==2018);
     }
}
