package StrategyPattern;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    //private static List<BookInformation> books;
    static BookLibrarian libary; 
    private static Scanner in = new Scanner(System.in);
    static ArrayList<BookInformation> books = new ArrayList<>();
    private static SortStrategy titleSortStrategy = new TitleSortStrategy();
    private static SortStrategy authorSortStrategy = new AuthorSortStrategy();
    private static SortStrategy yearSortStrategy = new YearSortStrategy();

    public static void main(String[] args) {
        init();
        menu();
    }

    private static void menu() {
        char choice;
        do {
            System.out.println("\n1- sort by author ");
            System.out.println("2- sort by Title ");
            System.out.println("3- sort by year published ");
            System.out.println("Q- quit ");

            choice = in.nextLine().charAt(0);
            switch (choice) {
                case '1':
                    System.out.println("\n Here is the List of Top20 Books sorted According to AUTHOR Name in Alphabetical Order:");
                    System.out.println("\n Title                                          Arthor              YearPublished        Summary \n" );

                    libary.setStrategy(authorSortStrategy);
                    libary.sortBooks();
                    libary.printBooks();
                   

                    
                    break;
                case '2':
                		System.out.println("\n Here is the List of Top20 Books sorted According to TITLE Name in Alphabetical Order:\n");
                    System.out.println("\n  Title                                          Arthor              YearPublished        1"
                    		+ "Summary \n");
                    libary.setStrategy(titleSortStrategy);
                    libary.sortBooks();
                    libary.printBooks();
                    break;
                case '3':
                		System.out.println("\n Here is the List of Top20 Books sorted According to Years they were published in acending order");
                    System.out.println("\n  Title                                          Arthor              YearPublished        Summary \n");
                    libary.setStrategy(yearSortStrategy);
                    libary.sortBooks();
                    libary.printBooks();
                    break;
            }
        } while (choice != 'q');
    }

    private static void init() {
        books.add(new BookInformation("Michael Wolf          ", "Fire and Fury: Inside the Trump White House    ", 2018	, "\t	summary book 1"));
        books.add(new BookInformation("A. J. Finn            ", "The Woman in the Window                        ", 2018	, "\t	summary book 2"));
        books.add(new BookInformation("Rupi Kaur             ", "Milk and Honey                                 ", 2015	, "\t	summary book 3"));
        books.add(new BookInformation("Madeleine L Engle     ", "A Wrinkle in Time (Time Quintet Series #1)     ", 2007	, "\t	summary book 4"));
        books.add(new BookInformation("Rupi Kaur             ", "The Sun and Her Flowers                        ", 2017	, "\t	summary book 5"));
        books.add(new BookInformation("Mark Manson           ", "The Subtle Art of Not Giving a F*ck            ", 2016	, "\t	summary book 6"));
        books.add(new BookInformation("Courtney Reum         ", "Shortcut Your Startup: Speed Up Success...     ", 2018	, "\t	summary book 7"));
        books.add(new BookInformation("Pete Souza            ", "Obama: An Intimate Portrait                    ", 2017	, "\t	summary book 8"));
        books.add(new BookInformation("Ben Lynch             ", "Dirty Genes: A Breakthrough Program to...      ", 2018	, "\t	summary book 9"));
        books.add(new BookInformation("Christine Comaford    ", "Power Your Tribe: Create Resilient Teams...    ", 2018	, "\t	summary book 10"));
        books.add(new BookInformation("Kristin Hannah        ", "The Great Alone                                ", 2018	, "\t	summary book 11"));
        books.add(new BookInformation("Celeste Ng            ", "Little Fires Everywhere                        ", 2017	, "\t	summary book 12"));
        books.add(new BookInformation("Wayne Jonas           ", "How Healing Works: Get Well and Stay ...       ", 2018	, "\t	summary book 13"));
        books.add(new BookInformation("Jordan B. Peterson    ", "12 Rules for Life: An Antidote to Chaos        ", 2018	, "\t	summary book 14"));
        books.add(new BookInformation("Karen M. McManus      ", "One of Us Is Lying                             ", 2017	, "\t	summary book 15"));
        books.add(new BookInformation("Lisa Wingate          ", "Before We Were Yours                           ", 2017	, "\t	summary book 16"));
        books.add(new BookInformation("Angie Thomas          ", "The Hate U Give                                ", 2017	, "\t	summary book 17"));
        books.add(new BookInformation("Martha Hall Kelly     ", "Lilac Girls                                    ", 2017	, "\t	summary book 18"));
        books.add(new BookInformation("Humble The Poet       ", "UnLearn: 101 Simple Truths For A Better Life   ", 2014	, "\t	summary book 19"));
        books.add(new BookInformation("Humble The Poet       ", "Beneath The Surface: 101 Honest Truths...      ", 2015	, "\t	summary book 20"));
        libary = new BookLibrarian(titleSortStrategy,books);
    }
}
