package StrategyPattern;

public class BookInformation {
    private String author;
    private String title;
    private int yearpublished;
    private String summary;

    public BookInformation(String author, String title, int yearpublished, String summary) {
        this.author = author;
        this.title = title;
        this.yearpublished = yearpublished;
        this.summary = summary;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getYearpublished() {
        return yearpublished;
    }

    public void setYearpublished(int yearpublished) {
        this.yearpublished = yearpublished;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }
    
    
    public String toString(){
            return title +", "+author+", "+yearpublished+", "+summary;
    }
}
