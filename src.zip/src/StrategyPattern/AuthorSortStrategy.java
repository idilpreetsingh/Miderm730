package StrategyPattern;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class AuthorSortStrategy  implements SortStrategy {
    @Override
    public void sort(List<BookInformation> bookInformationList) {
        Collections.sort(bookInformationList, new Comparator<BookInformation>() {
            @Override
            public int compare(BookInformation o1, BookInformation o2) {
                return o1.getAuthor().compareTo(o2.getAuthor());
            }
        });
    }
}
