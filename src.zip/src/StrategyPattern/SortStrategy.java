package StrategyPattern;


import java.util.List;

public interface SortStrategy {
    void sort(List<BookInformation> bookInformationList);
}
