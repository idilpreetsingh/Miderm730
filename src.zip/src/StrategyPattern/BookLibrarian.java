/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package StrategyPattern;

import java.util.List;


public class BookLibrarian {
    SortStrategy strategy;
    List<BookInformation> books;
    public BookLibrarian(SortStrategy _strategy,List<BookInformation> _books)
    {
        strategy = _strategy;
        books = _books;
    }
    public void setStrategy(SortStrategy _strategy)
    {
        strategy = _strategy;
    }
    public void sortBooks()
    {
        strategy.sort(books);
    }
    public void printBooks()
    {
        for(BookInformation info : books)
        {
            System.out.println(info);
        }
    }
}
