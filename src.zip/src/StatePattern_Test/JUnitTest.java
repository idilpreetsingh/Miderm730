/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import State.Ready;
import State.ServiceContext;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Dilpreet
 */
public class JUnitTest {
    ServiceContext serviceContext;
    public JUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
     @Test
     public void testServiceContextConstructor() {
         serviceContext = new ServiceContext("Health Care Srvice 1");
         assertTrue(serviceContext.getState() instanceof State.Unknown);
     }
     @Test
     public void testServiceContextUnknowToReady() {
         serviceContext = new ServiceContext("Health Care Srvice 1");
         serviceContext.goToNextState(State.ServiceState.HEALTH_CHECK_GOOD);
         assertTrue(serviceContext.getState() instanceof State.Ready);
     }
     @Test
     public void testServiceContextUnknowToDown1() {
         serviceContext = new ServiceContext("Health Care Srvice 1");
         serviceContext.goToNextState(State.ServiceState.SERVICE_TIME_OUT);
         assertTrue(serviceContext.getState() instanceof State.Down);
     }
     @Test
     public void testServiceContextUnknowToDown2() {
         serviceContext = new ServiceContext("Health Care Srvice 1");
         serviceContext.goToNextState(State.ServiceState.HEALTH_CHECK_BAD);
         assertTrue(serviceContext.getState() instanceof State.Down);
     }
     @Test
     public void testServiceContextReadyToUnknow() {
         serviceContext = new ServiceContext("Health Care Srvice 1");
         serviceContext.setState(new State.Ready());
         serviceContext.goToNextState(State.ServiceState.SERVICE_TIME_OUT);
         assertTrue(serviceContext.getState() instanceof State.Unknown);
     }
     @Test
     public void testServiceContextReadyToDown() {
         serviceContext = new ServiceContext("Health Care Srvice 1");
         serviceContext.setState(new State.Ready());
         serviceContext.goToNextState(State.ServiceState.HEALTH_CHECK_BAD);
         assertTrue(serviceContext.getState() instanceof State.Down);
     }
     @Test
     public void testServiceContextReadyToDisable() {
         serviceContext = new ServiceContext("Health Care Srvice 1");
         serviceContext.setState(new State.Ready());
         serviceContext.goToNextState(State.ServiceState.HEALTH_SERVICE_DISABLE);
         assertTrue(serviceContext.getState() instanceof State.Disabled);
     }
     @Test
     public void testServiceContextDisableToUnknown() {
         serviceContext = new ServiceContext("Health Care Srvice 1");
         serviceContext.setState(new State.Disabled());
         serviceContext.goToNextState(State.ServiceState.HEALTH_SERVICE_ENABLE);
         assertTrue(serviceContext.getState() instanceof State.Unknown);
     }
}
